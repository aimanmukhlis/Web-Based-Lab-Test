<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Schedule List</title>
    </head>
    <body>
        <table class="table table-bordered">
            <thead>
                <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Branch</th>
                <th>Lesson Type</th>
                <th>Status</th>
                </tr>
                </thead>
            <tbody>
            <c:forEach var="session"
            items="${list}">
            <tr>
            <td><c:out value="${session.id}"/></td>
            <td><c:out value="${session.stuname}"/></td>
            <td><c:out value="${session.branchloc}"/></td>
            <td><c:out value="${session.lesstype}"/></td>
            <td><c:out value="${session.status}"/></td>
            </tr>
            </c:forEach>
            </tbody>
        </table>
    </body>
</html>
