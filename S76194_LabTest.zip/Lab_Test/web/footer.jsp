<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@page import="java.util.Date" %>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>JSP Page</title>
        <style>
        footer {
        text-align: center;
        padding: 3px;
        background-color: burlywood;
        color: white;
        }
        </style>
    </head>
    
    <%
        Date date = new Date();
        %>
    <body>
        <footer>
            <p>&COPY;Paduu<br>
            <p>DATE and TIME NOW
                <%=date%>
            </p>
        </footer>
    </body>
</html>
