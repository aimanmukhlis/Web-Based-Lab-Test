<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@include file="header.html" %>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Drivesmart Academy</title>
    </head>
    <body>
        <nav>
            <ul>
                <li><a href="booksession.jsp">Book Session</a></li>
                <li><a href="schedule.jsp">Schedule List</a></li>
            </ul>
        </nav>
    </body>
</html>
<%@include file="footer.jsp" %>
