<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Booking Session</title>
    </head>
    <body>
        
        <form action="BookSessionServlet" method="post">
            <fieldset>
                <label for="stuname">STUDENT NAME:</label>
                <input type="text" name="student_name" id="student_name"><br><br>
                
                <label for="branchloc">BRANCH LOCATION:</label>
                <select name="branch_location" id="branch_location">
                    <option value="Kuala_Lumpur">KUALA LUMPUR</option>
                    <option value="Penang">PENANG</option>
                    <option value="Johor">JOHOR</option>
                </select>
                <br><br><!-- comment -->
                
                <label for="lesstype">LESSON TYPE:</label>
                <select name="lesson_type" id="lesson_type">
                    <option value="Manual_Car">MANUAL CAR</option>
                    <option value="Automatic_Car">AUTOMATIC CAR</option>
                    <option value="Motorcycle">MOTORCYCLE</option>
                </select>
                <br><br>
                
                <input type="submit" value="SUBMIT">
            </fieldset>
        </form>
    </body>
</html>
