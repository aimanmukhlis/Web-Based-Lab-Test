
package com.lab.controller;


import java.sql.SQLException;
import java.util.List;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.lab.bean.SessionBean;
import com.lab.dao.SessionDAO;

@WebServlet("/")
public class BookSessionServlet extends HttpServlet {
    private SessionDAO sessionDAO;
    
    public void init(){
        sessionDAO = new SessionDAO();
    }
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
    }
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
            SessionBean newsession = new SessionBean();
                newsession.setStudent_name(request.getParameter("student_name"));
                newsession.setBranch_location(request.getParameter("branch_location"));
                newsession.setLesson_type(request.getParameter("lesson_type"));
                newsession.setStatus("Booked");
                
                boolean isSuccess = sessionDAO.insertSession(newsession);
                if(isSuccess){
                    response.sendRedirect("ScheduleServlet.java");
                }else{
                    response.sendRedirect("booksession.jsp");
                }
    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }

}
