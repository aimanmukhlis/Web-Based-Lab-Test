
package com.lab.controller;

import java.sql.SQLException;
import java.util.List;
import java.io.IOException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.lab.bean.SessionBean;
import com.lab.dao.SessionDAO;

public class ScheduleServlet extends HttpServlet {
    private SessionDAO sessionDAO;
    
    public void init(){
        sessionDAO = new SessionDAO();
    }
    
    protected void doPost(HttpServletRequest request,
    HttpServletResponse response)
    throws ServletException, IOException {
    doGet(request, response);
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        List < SessionBean > list = sessionDAO.selectAllsession();
        request.setAttribute("sessionList", list);
        RequestDispatcher rd = request.getRequestDispatcher("schedule.jsp");
        rd.forward(request, response);
    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
