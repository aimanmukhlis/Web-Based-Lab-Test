
package com.lab.dao;

import com.lab.bean.SessionBean;
import java.sql.*;
import java.util.List;
import java.util.ArrayList;

public class SessionDAO {
    private String jdbcurl ="jdbc:mysql://localhost:3306/drivesmart_db";
    private String user ="root";
    private String pass ="";
    
    protected Connection getConnection(){
        Connection connection = null;
        
        try{
            Class.forName("com.mysql.jdbc.Driver");
            connection = DriverManager.getConnection(jdbcurl,
            user, pass);
            
        }catch(SQLException e){
            e.printStackTrace();
        }catch(ClassNotFoundException e){
            e.printStackTrace();
        }
        return connection;
    }
    
    public boolean insertSession(SessionBean session){
        try (Connection connection = getConnection();
        PreparedStatement ps = connection.
        prepareStatement("INSERT INTO TRAINING_SESSION (student_name,branch_location,lesson_type,status) values (?,?,?,?)")) {
        ps.setString(1, session.getStudent_name());
        ps.setString(2, session.getBranch_location());
        ps.setString(3, session.getLesson_type());
        ps.setString(4, session.getStatus());
        System.out.println(ps);
        
        return ps.executeUpdate()>0;
        } catch (SQLException e) {
        printSQLException(e);
        }
        return false;
    }   
            
    public List < SessionBean > selectAllsession() {
    // using try-with-resources to avoid closing resources (boiler plate code)
    List < SessionBean > session = new ArrayList < > ();
    // Step 1: Establishing a Connection
    try (Connection connection = getConnection();
    // Step 2: Create a statement using connection object
    PreparedStatement ps = connection.prepareStatement("SELECT * FROM Training_Sessions ORDER BY branch_location ASC");) {
    System.out.println(ps);
    // Step 3: Execute the query or update query
    ResultSet rs = ps.executeQuery();
    // Step 4: Process the ResultSet object.
    while (rs.next()) {
    int id = rs.getInt("session_id");
    String stuname = rs.getString("student_name");
    String branchloc = rs.getString("branch_location");
    String lesstype = rs.getString("lesson_type");
    String status = rs.getString("status");
    session.add(new SessionBean(id,stuname, branchloc, lesstype,status));
    }
    } catch (SQLException e) {
    printSQLException(e);
    }
    return session;
}

    
    private void printSQLException(SQLException ex) {
        for (Throwable e: ex) {
            if (e instanceof SQLException) {
                e.printStackTrace(System.err);
                    System.err.println("SQLState: " + ((SQLException)
                    e).getSQLState());
                    System.err.println("Error Code: " + ((SQLException)
                    e).getErrorCode());
                    System.err.println("Message: " + e.getMessage());
                    Throwable t = ex.getCause();
                    while (t != null) {
                    System.out.println("Cause: " + t);
                    t = t.getCause();
                    }
                }
            }
        }
    }
    

